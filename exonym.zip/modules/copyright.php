<p class="copyright">&copy;<?php echo date('Y') . ' '; ex_brand('legal'); ?></p>
