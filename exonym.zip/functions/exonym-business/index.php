<?php // Silence is Golden
