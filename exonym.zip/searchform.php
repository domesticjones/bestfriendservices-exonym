<form role="search" method="get" class="search-form-inline" action="<?php echo home_url( '/' ); ?>">
	<input type="search" class="search-field" placeholder="Search&mldr;" value="" name="s" title="Search for:" />
	<button type="submit" class="search-submit" value="Search" /><span>Search</span></button>
</form>
